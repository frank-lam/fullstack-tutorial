### 3 hashes as top level
foo bar
#### sub level1-1 with special " ' & #'"
foo bar
#### sub level1-2 (parentheses)
foo bar
#####sub 1-2-1
foo bar
#####sub 1-2-2 <foo>
foo bar
### 3 hashes as top level2
foo bar
#### sub level2-1 with special " ' & #'"
foo bar
#### sub level2-2 (parentheses)
foo bar
#####sub 2-2-1
foo bar
#####sub 2-2-2 <foo>
